[main]
title_ro			=	Actualizări
title_en			=	Upgrades
image				  =	images/upgrades_24.png
