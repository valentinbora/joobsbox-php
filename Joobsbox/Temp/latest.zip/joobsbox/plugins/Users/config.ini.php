[main]
title_ro			=	Utilizatori
title_en			=	Users
image				  =	images/users_24.png