[main]
title_ro			=	Opțiuni
title_en			=	Settings
image				  =	images/settings_24.png
