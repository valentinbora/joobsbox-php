[main]
title_ro			=	Google Analytics
title_en			=	Google Analytics
image				  =	images/google_analytics_24.png
version       = 0.1
description   = Google Analytics plugin adds the Analytics tracking code to your site and displays statistics about your site's traffic.
