[main]
title_en  = Logger
title_ro  = Jurnal
version   = 0.1
image     = logger.png
description = Logger plugin lets developers log stuff through FirePHP easily.
