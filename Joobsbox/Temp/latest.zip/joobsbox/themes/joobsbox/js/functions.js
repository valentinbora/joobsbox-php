$("div.box, div.plain").corner("round top");
$("div.outer").corner("round top");
