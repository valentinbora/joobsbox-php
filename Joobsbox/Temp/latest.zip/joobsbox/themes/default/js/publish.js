$(function() {
	$("#expirationDate").datepicker({minDate: -0});
});
