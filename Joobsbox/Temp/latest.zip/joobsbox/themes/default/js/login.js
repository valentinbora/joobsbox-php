$(function(){
	$("#username").focus();
	$("#loginForm").corner("round");
	$("#submit").addClass("button");
});
